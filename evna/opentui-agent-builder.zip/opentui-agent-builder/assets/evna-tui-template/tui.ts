/**
 * Main TUI entry point
 * Example integration with Claude Agent SDK
 */

import { createCliRenderer, ConsolePosition } from "@opentui/core"
import { ConversationLoop } from "./components/ConversationLoop"
import type { AgentMessage } from "./types"

// Import your Agent SDK setup
// import { query, tool } from "@anthropic-ai/claude-agent-sdk"
// import { myTools } from "./tools"

async function main() {
  // Create OpenTUI renderer
  const renderer = await createCliRenderer({
    exitOnCtrlC: true,
    consoleOptions: {
      position: ConsolePosition.BOTTOM,
      sizePercent: 30,
      colorInfo: "#00FFFF",
      colorWarn: "#FFFF00",
      colorError: "#FF0000",
      startInDebugMode: false,
    },
  })

  console.log("🧠 TUI Started - Press ` to toggle console, Ctrl+C to exit")

  // Create conversation loop
  const loop = new ConversationLoop(renderer, {
    onSubmit: async (userInput: string) => {
      // TODO: Replace with your Agent SDK query
      // return await query(userInput, myTools)

      // Mock response for testing
      return mockAgentResponse(userInput)
    },
    formatMessage: (response: any): AgentMessage => {
      // TODO: Format your Agent SDK response
      // Agent SDK responses should already match the AgentMessage interface
      return response
    },
    enableConsole: true,
  })

  renderer.root.add(loop)

  // Start the render loop
  renderer.start()
}

/**
 * Mock Agent SDK response for testing
 * Replace with actual Agent SDK integration
 */
function mockAgentResponse(userInput: string): AgentMessage {
  // Simulate processing delay
  return {
    role: "assistant",
    content: [
      {
        type: "text",
        text: `I received your message: "${userInput}"\n\nThis is a mock response. Replace the onSubmit handler with your actual Agent SDK query() call.`,
      },
      {
        type: "tool_use",
        id: "toolu_mock_123",
        name: "search",
        input: {
          query: "example search",
          limit: 5,
        },
      },
    ],
    usage: {
      input_tokens: 150,
      output_tokens: 75,
    },
  }
}

/**
 * Example: Real Agent SDK Integration
 *
 * import { query, tool } from "@anthropic-ai/claude-agent-sdk"
 * import { z } from "zod"
 * import { DatabaseClient } from "./lib/db"
 * import { EmbeddingsClient } from "./lib/embeddings"
 *
 * // Initialize clients
 * const db = new DatabaseClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!)
 * const embeddings = new EmbeddingsClient(process.env.OPENAI_API_KEY!)
 *
 * // Define tools
 * const searchTool = tool(
 *   "semantic_search",
 *   "Search conversation history with semantic similarity",
 *   {
 *     query: z.string().describe("Search query"),
 *     limit: z.number().optional().describe("Max results (default 10)"),
 *   },
 *   async (args) => {
 *     const results = await db.semanticSearch(args.query, args.limit ?? 10)
 *     return {
 *       content: [{ type: "text" as const, text: JSON.stringify(results) }],
 *     }
 *   }
 * )
 *
 * const tools = [searchTool]
 *
 * // In ConversationLoop options:
 * onSubmit: async (userInput: string) => {
 *   return await query(userInput, tools)
 * }
 */

// Run the TUI
main().catch((error) => {
  console.error("Fatal error:", error)
  process.exit(1)
})
