# OpenTUI Implementation Patterns

Deep-dive reference for implementing OpenTUI components in Agent SDK applications.

## Table of Contents

1. [Multi-Line Input Implementation](#multi-line-input-implementation)
2. [Keyboard Event Handling](#keyboard-event-handling)
3. [Focus Management](#focus-management)
4. [Agent SDK Message Parsing](#agent-sdk-message-parsing)
5. [Streaming Responses](#streaming-responses)
6. [Tree-sitter Syntax Highlighting](#tree-sitter-syntax-highlighting)
7. [Layout Patterns](#layout-patterns)

---

## Multi-Line Input Implementation

OpenTUI's built-in `InputRenderable` is single-line only. Here's how to implement a custom multi-line input component with tab support.

### Core Data Structure

```typescript
interface CursorPosition {
  line: number  // 0-indexed line number
  col: number   // 0-indexed character position in line
}

class MultilineInput extends BoxRenderable {
  private lines: string[] = []  // Internal line storage
  private cursor: CursorPosition = { line: 0, col: 0 }
  private scrollOffset: number = 0  // For vertical scrolling
  private focused: boolean = false
}
```

### Keyboard Handler

```typescript
private handleKeypress(key: KeyEvent): void {
  if (!this.focused) return

  // Submit on Ctrl+Enter
  if (key.ctrl && key.name === "return") {
    this.emit("submit", this.lines.join("\n"))
    return
  }

  // Newline on plain Enter
  if (key.name === "return") {
    const currentLine = this.lines[this.cursor.line]
    const beforeCursor = currentLine.slice(0, this.cursor.col)
    const afterCursor = currentLine.slice(this.cursor.col)

    this.lines[this.cursor.line] = beforeCursor
    this.lines.splice(this.cursor.line + 1, 0, afterCursor)
    this.cursor.line++
    this.cursor.col = 0
    this.updateScrollOffset()
    this.render()
    return
  }

  // Tab insertion (literal \t character)
  if (key.name === "tab" && !key.shift) {
    const currentLine = this.lines[this.cursor.line]
    this.lines[this.cursor.line] =
      currentLine.slice(0, this.cursor.col) +
      "\t" +
      currentLine.slice(this.cursor.col)
    this.cursor.col++
    this.render()
    return
  }

  // Backspace
  if (key.name === "backspace") {
    if (this.cursor.col > 0) {
      // Delete character before cursor
      const currentLine = this.lines[this.cursor.line]
      this.lines[this.cursor.line] =
        currentLine.slice(0, this.cursor.col - 1) +
        currentLine.slice(this.cursor.col)
      this.cursor.col--
    } else if (this.cursor.line > 0) {
      // Join with previous line
      const currentLine = this.lines[this.cursor.line]
      this.cursor.line--
      this.cursor.col = this.lines[this.cursor.line].length
      this.lines[this.cursor.line] += currentLine
      this.lines.splice(this.cursor.line + 1, 1)
      this.updateScrollOffset()
    }
    this.render()
    return
  }

  // Arrow key navigation
  if (key.name === "up" && this.cursor.line > 0) {
    this.cursor.line--
    this.cursor.col = Math.min(this.cursor.col, this.lines[this.cursor.line].length)
    this.updateScrollOffset()
    this.render()
    return
  }

  if (key.name === "down" && this.cursor.line < this.lines.length - 1) {
    this.cursor.line++
    this.cursor.col = Math.min(this.cursor.col, this.lines[this.cursor.line].length)
    this.updateScrollOffset()
    this.render()
    return
  }

  if (key.name === "left" && this.cursor.col > 0) {
    this.cursor.col--
    this.render()
    return
  }

  if (key.name === "right") {
    const currentLine = this.lines[this.cursor.line]
    if (this.cursor.col < currentLine.length) {
      this.cursor.col++
      this.render()
    }
    return
  }

  // Home/End keys
  if (key.name === "home") {
    this.cursor.col = 0
    this.render()
    return
  }

  if (key.name === "end") {
    this.cursor.col = this.lines[this.cursor.line].length
    this.render()
    return
  }

  // Regular character input
  if (key.sequence && key.sequence.length === 1) {
    const currentLine = this.lines[this.cursor.line]
    this.lines[this.cursor.line] =
      currentLine.slice(0, this.cursor.col) +
      key.sequence +
      currentLine.slice(this.cursor.col)
    this.cursor.col++
    this.render()
  }
}
```

### Rendering with Scroll Support

```typescript
protected renderSelf(buffer: OptimizedBuffer): void {
  super.renderSelf(buffer)

  const visibleHeight = this.height - 2  // Account for border
  const visibleWidth = this.width - 2

  // Render visible lines (with scroll offset)
  for (let i = 0; i < visibleHeight; i++) {
    const lineIndex = this.scrollOffset + i
    if (lineIndex >= this.lines.length) break

    const line = this.lines[lineIndex]
    const displayLine = this.expandTabs(line)  // Convert \t to spaces

    // Render line text
    buffer.drawText(
      displayLine.slice(0, visibleWidth),
      this.x + 1,
      this.y + 1 + i,
      this.textColor
    )

    // Render cursor if on this line
    if (this.focused && lineIndex === this.cursor.line) {
      const cursorX = this.x + 1 + this.expandTabs(line.slice(0, this.cursor.col)).length
      const cursorY = this.y + 1 + i
      buffer.setCell(cursorX, cursorY, "█", this.cursorColor, this.backgroundColor)
    }
  }

  // Render scrollbar if needed
  if (this.lines.length > visibleHeight) {
    this.renderScrollbar(buffer, visibleHeight)
  }
}

private expandTabs(text: string, tabWidth: number = 4): string {
  return text.replace(/\t/g, " ".repeat(tabWidth))
}

private updateScrollOffset(): void {
  const visibleHeight = this.height - 2

  // Scroll down if cursor is below visible area
  if (this.cursor.line >= this.scrollOffset + visibleHeight) {
    this.scrollOffset = this.cursor.line - visibleHeight + 1
  }

  // Scroll up if cursor is above visible area
  if (this.cursor.line < this.scrollOffset) {
    this.scrollOffset = this.cursor.line
  }
}
```

---

## Keyboard Event Handling

### KeyEvent Structure

```typescript
interface KeyEvent {
  name: string         // Key name: "a", "return", "tab", "escape", "up", etc.
  sequence: string     // Raw key sequence from terminal
  ctrl: boolean        // Ctrl modifier
  shift: boolean       // Shift modifier
  meta: boolean        // Alt/Meta modifier
  option: boolean      // Option modifier (macOS)
}
```

### Global vs Component-Level Handlers

**Global handler** (renderer-level):
```typescript
renderer.keyInput.on("keypress", (key: KeyEvent) => {
  // Handle global shortcuts
  if (key.sequence === "`") {
    renderer.console.toggle()
  }

  if (key.ctrl && key.name === "l") {
    conversationLoop.clear()
  }

  if (key.name === "escape") {
    conversationLoop.toggleFocus()
  }
})
```

**Component-level handler** (for focused components):
```typescript
class MultilineInput extends BoxRenderable {
  constructor(renderer: CliRenderer, options: any) {
    super(renderer, options)

    this.keyHandler = (key: KeyEvent) => {
      if (!this.focused) return
      this.handleKeypress(key)
    }

    renderer.keyInput.on("keypress", this.keyHandler)
  }

  destroy(): void {
    this.renderer.keyInput.off("keypress", this.keyHandler)
    super.destroy()
  }
}
```

**Tip**: Always remove event handlers in `destroy()` to prevent memory leaks.

---

## Focus Management

### Single Active Component

Only one component should handle keyboard input at a time. Implement focus tracking:

```typescript
class FocusManager {
  private focused: Renderable | null = null

  focus(component: Renderable): void {
    if (this.focused) {
      this.focused.blur()
    }
    this.focused = component
    component.focus()
  }

  blur(): void {
    if (this.focused) {
      this.focused.blur()
      this.focused = null
    }
  }

  getFocused(): Renderable | null {
    return this.focused
  }
}
```

### Toggle Focus Pattern

For conversation UIs, toggle focus between input and history:

```typescript
class ConversationLoop {
  private focusState: "input" | "history" = "input"

  toggleFocus(): void {
    if (this.focusState === "input") {
      this.input.blur()
      this.history.focus()
      this.focusState = "history"
    } else {
      this.history.blur()
      this.input.focus()
      this.focusState = "input"
    }
  }

  // Bind to Escape key
  constructor(renderer: CliRenderer) {
    renderer.keyInput.on("keypress", (key) => {
      if (key.name === "escape") {
        this.toggleFocus()
      }
    })
  }
}
```

---

## Agent SDK Message Parsing

### Message Structure

Agent SDK returns messages with this structure:

```typescript
interface AgentMessage {
  role: "user" | "assistant" | "system"
  content: ContentBlock[]
  usage?: {
    input_tokens: number
    output_tokens: number
    cache_read_input_tokens?: number
    cache_creation_input_tokens?: number
  }
  stop_reason?: string
  model?: string
}

type ContentBlock =
  | { type: "text"; text: string }
  | { type: "tool_use"; id: string; name: string; input: any }
  | { type: "tool_result"; tool_use_id: string; content: any; is_error: boolean }
  | { type: "thinking"; thinking: string }  // Extended thinking
```

### Formatting Tool Calls

```typescript
function formatToolUse(toolUse: ToolUseBlock): string {
  const inputStr = JSON.stringify(toolUse.input, null, 2)
  return `
🔧 Tool: ${toolUse.name}
   Input: ${inputStr}
   ID: ${toolUse.id}
  `.trim()
}

function formatToolResult(result: ToolResultBlock, duration?: number): string {
  const statusEmoji = result.is_error ? "❌" : "✅"
  const durationStr = duration ? ` (${duration}ms)` : ""

  return `
${statusEmoji} Result${durationStr}:
${formatToolContent(result.content)}
  `.trim()
}

function formatToolContent(content: any): string {
  if (typeof content === "string") {
    return content
  }
  if (Array.isArray(content)) {
    return content.map(block => {
      if (block.type === "text") return block.text
      return JSON.stringify(block, null, 2)
    }).join("\n")
  }
  return JSON.stringify(content, null, 2)
}
```

### Color Scheme

```typescript
const MESSAGE_COLORS = {
  user: "#00FF00",        // Green
  assistant: "#00AAFF",   // Blue
  system: "#FFAA00",      // Orange
  tool_use: "#FF00FF",    // Magenta
  tool_result_success: "#00FF00",  // Green
  tool_result_error: "#FF0000",    // Red
  thinking: "#888888",    // Gray (subtle)
}
```

---

## Streaming Responses

### Basic Streaming Pattern

```typescript
import { queryStream } from "@anthropic-ai/claude-agent-sdk"

async function handleStreamingQuery(
  userInput: string,
  tools: Tool[],
  messageRenderer: MessageRenderer
): Promise<void> {
  const stream = queryStream(userInput, tools)

  // Create placeholder for streaming message
  const messageBox = messageRenderer.createPlaceholder({
    role: "assistant",
    id: generateId(),
  })

  let currentText = ""
  const toolCalls: any[] = []

  for await (const chunk of stream) {
    switch (chunk.type) {
      case "content_block_start":
        if (chunk.content_block.type === "text") {
          currentText = ""
        }
        break

      case "content_block_delta":
        if (chunk.delta.type === "text_delta") {
          currentText += chunk.delta.text
          messageBox.updateText(currentText)
        }
        break

      case "content_block_stop":
        // Content block complete
        break

      case "message_start":
        // Initialize message metadata
        break

      case "message_delta":
        // Update usage stats
        if (chunk.usage) {
          messageBox.updateUsage(chunk.usage)
        }
        break

      case "message_stop":
        // Message complete
        messageBox.markComplete()
        break
    }
  }
}
```

### Handling Tool Calls in Streams

```typescript
for await (const chunk of stream) {
  if (chunk.type === "content_block_start") {
    if (chunk.content_block.type === "tool_use") {
      const toolUse = chunk.content_block
      const toolBox = messageBox.addToolCall({
        id: toolUse.id,
        name: toolUse.name,
        input: toolUse.input,
      })
    }
  }

  // Agent SDK automatically handles tool execution
  // Listen for tool results
  if (chunk.type === "tool_result") {
    messageBox.addToolResult({
      tool_use_id: chunk.tool_use_id,
      content: chunk.content,
      is_error: chunk.is_error,
    })
  }
}
```

---

## Tree-sitter Syntax Highlighting

### Setup

```bash
# Install Tree-sitter languages
bun install tree-sitter-typescript tree-sitter-javascript tree-sitter-python
```

### Integration

```typescript
import {
  TreeSitterStyledText,
  TreeSitterLanguage,
} from "@opentui/core"

function renderCodeBlock(
  renderer: CliRenderer,
  code: string,
  language: string
): TreeSitterStyledText {
  // Map language string to Tree-sitter language
  const langMap: Record<string, TreeSitterLanguage> = {
    typescript: "typescript",
    javascript: "javascript",
    python: "python",
    // Add more as needed
  }

  return new TreeSitterStyledText(renderer, {
    id: `code-${Date.now()}`,
    content: code,
    language: langMap[language] || "typescript",
    theme: "monokai",  // or "github-light", "dracula", etc.
    position: "relative",
    padding: 1,
  })
}
```

### Custom Themes

```typescript
const customTheme = {
  keyword: "#FF79C6",
  string: "#F1FA8C",
  number: "#BD93F9",
  comment: "#6272A4",
  function: "#50FA7B",
  variable: "#F8F8F2",
  operator: "#FF79C6",
}

const codeBlock = new TreeSitterStyledText(renderer, {
  content: code,
  language: "typescript",
  customTheme,
})
```

---

## Layout Patterns

### Flex Layout (Responsive)

```typescript
import { GroupRenderable, BoxRenderable } from "@opentui/core"

// Vertical split container
const container = new GroupRenderable(renderer, {
  id: "main-container",
  flexDirection: "column",  // Stack vertically
  width: "100%",
  height: "100%",
})

// History takes 70% of space
const history = new BoxRenderable(renderer, {
  id: "history",
  flexGrow: 7,
  overflow: "scroll",
  backgroundColor: "#1a1a1a",
})

// Input takes 30% of space
const input = new MultilineInput(renderer, {
  id: "input",
  flexGrow: 3,
  minHeight: 5,  // Prevent collapse
  backgroundColor: "#2a2a2a",
})

container.add(history)
container.add(input)
renderer.root.add(container)
```

### Absolute Positioning (Fixed Layout)

```typescript
// History at top
const history = new BoxRenderable(renderer, {
  id: "history",
  position: "absolute",
  left: 0,
  top: 0,
  width: "100%",
  height: "calc(100% - 12)",  // Leave space for input
  overflow: "scroll",
})

// Input at bottom (fixed 12 lines)
const input = new MultilineInput(renderer, {
  id: "input",
  position: "absolute",
  left: 0,
  bottom: 0,
  width: "100%",
  height: 12,
})

renderer.root.add(history)
renderer.root.add(input)
```

### Three-Panel Layout

```typescript
const container = new GroupRenderable(renderer, {
  flexDirection: "row",  // Horizontal split
  width: "100%",
  height: "100%",
})

// Sidebar (20%)
const sidebar = new BoxRenderable(renderer, {
  flexGrow: 2,
  backgroundColor: "#1a1a1a",
})

// Main content (60%)
const main = new GroupRenderable(renderer, {
  flexGrow: 6,
  flexDirection: "column",
})

// Info panel (20%)
const info = new BoxRenderable(renderer, {
  flexGrow: 2,
  backgroundColor: "#1a1a1a",
})

container.add(sidebar)
container.add(main)
container.add(info)
```

---

## Performance Tips

1. **Batch Updates**: Group state changes to trigger fewer re-renders
2. **Virtualization**: For long message lists, only render visible items
3. **Debounce Input**: Don't re-render on every keystroke for search/filter
4. **Memoize Formatters**: Cache formatted message components
5. **Lazy Load**: Load syntax highlighting only when code blocks are visible

```typescript
// Example: Batch updates
class MessageRenderer {
  private pendingUpdates: Message[] = []
  private updateTimer: NodeJS.Timeout | null = null

  addMessage(msg: Message): void {
    this.pendingUpdates.push(msg)

    if (!this.updateTimer) {
      this.updateTimer = setTimeout(() => {
        this.flushUpdates()
        this.updateTimer = null
      }, 16)  // ~60 FPS
    }
  }

  private flushUpdates(): void {
    // Process all pending messages at once
    this.pendingUpdates.forEach(msg => this.renderMessage(msg))
    this.pendingUpdates = []
  }
}
```

---

## Debugging Tips

1. **Use Console Overlay**: Log to console.log() without disrupting TUI
2. **Visual Indicators**: Show focus states, processing states clearly
3. **Error Boundaries**: Catch and display errors gracefully
4. **State Inspection**: Add debug panel with `Ctrl+D` to show internal state

```typescript
renderer.keyInput.on("keypress", (key) => {
  if (key.ctrl && key.name === "d") {
    console.log("Current State:", {
      focusState: conversationLoop.focusState,
      messageCount: conversationLoop.messages.length,
      inputValue: conversationLoop.input.getValue(),
      cursorPosition: conversationLoop.input.getCursor(),
    })
  }
})
```
