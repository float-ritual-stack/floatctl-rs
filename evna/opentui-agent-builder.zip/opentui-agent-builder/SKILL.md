---
name: opentui-agent-builder
description: Build terminal UIs with OpenTUI for Claude Agent SDK applications. Use when creating interactive REPL interfaces, conversation loops, multi-line input handlers, or formatting Agent SDK messages (reasoning, tool calls, streaming) in a TUI. Provides patterns for keyboard handling, state management, and integrating OpenTUI renderables with Agent SDK workflows.
---

# OpenTUI Agent Builder

## Overview

Build interactive terminal user interfaces (TUIs) for Claude Agent SDK applications using OpenTUI. This skill provides patterns, reference implementations, and boilerplate for creating REPL-style conversation interfaces with multi-line input, tool call visualization, and streaming message rendering.

**Use this skill when:**
- Building a TUI REPL for an Agent SDK application (replacing JSON stdout dumps)
- Need multi-line input with tab support for prompts
- Want to format Agent SDK messages (reasoning, tool calls, results) clearly in the terminal
- Creating interactive conversation loops with keyboard navigation
- Integrating OpenTUI components with Agent SDK query/tool workflows

## Quick Start

**1. Install OpenTUI in your Agent SDK project:**
```bash
bun install @opentui/core
# or with npm/pnpm
npm install @opentui/core
```

**2. Use the boilerplate template:**

Copy the `assets/evna-tui-template/` directory into your project. It provides:
- `tui.ts` - Main TUI entry point with CliRenderer setup
- `components/MultilineInput.ts` - Custom multi-line input with tab support
- `components/MessageRenderer.ts` - Agent SDK message formatter (tool calls, reasoning)
- `components/ConversationLoop.ts` - Interactive REPL loop with state management

**3. Integrate with your Agent SDK app:**

```typescript
import { createCliRenderer } from "@opentui/core"
import { ConversationLoop } from "./components/ConversationLoop"
import { query } from "@anthropic-ai/claude-agent-sdk"

const renderer = await createCliRenderer({ exitOnCtrlC: true })
const loop = new ConversationLoop(renderer, {
  onSubmit: async (userMessage) => {
    // Integrate with Agent SDK
    return await query("Your Agent SDK query...", tools)
  }
})

renderer.start()
```

## Core Patterns

### Multi-Line Input with Tab Support

OpenTUI's `InputRenderable` is single-line only. For multi-line input (critical for Agent SDK prompts), use the custom `MultilineInput` component in `assets/evna-tui-template/components/MultilineInput.ts`.

**Key features:**
- Line-based text editing with cursor navigation
- Tab character support (preserved in input)
- Enter for newlines, Ctrl+Enter to submit
- Vertical scrolling for long inputs
- Syntax highlighting integration (optional)

**Usage:**
```typescript
import { MultilineInput } from "./components/MultilineInput"

const input = new MultilineInput(renderer, {
  id: "prompt-input",
  width: 80,
  height: 10,
  placeholder: "Enter your message... (Ctrl+Enter to submit)",
  position: "absolute",
  left: 2,
  top: 2,
})

input.on("submit", (value: string) => {
  console.log("User submitted:", value)
  // Process with Agent SDK
})

input.focus()
```

**Implementation notes:**
- Stores lines as `string[]` internally
- Uses `renderer.keyInput.on("keypress", ...)` for keyboard handling
- Implements cursor position tracking: `{ line: number, col: number }`
- Tab key inserts literal `\t` character (not focus navigation)
- Ctrl+Enter submits, plain Enter adds newline

### Agent SDK Message Formatting

The Agent SDK returns rich message structures with tool calls, reasoning, and results. Format these clearly using the `MessageRenderer` component.

**Message types to handle:**
1. **System init** - Model, tools, session info
2. **User messages** - Display with user indicator
3. **Assistant messages** - Content blocks (text, tool use)
4. **Tool results** - Success/error states, duration, costs
5. **Reasoning** - Extended thinking blocks

**Example formatter:**
```typescript
import { MessageRenderer } from "./components/MessageRenderer"

const messageRenderer = new MessageRenderer(renderer, {
  id: "messages",
  width: "100%",
  position: "relative",
})

// Add assistant message with tool calls
messageRenderer.addMessage({
  role: "assistant",
  content: [
    { type: "text", text: "Let me search for that..." },
    {
      type: "tool_use",
      id: "call_123",
      name: "semantic_search",
      input: { query: "pharmacy project", limit: 5 }
    }
  ],
  usage: { input_tokens: 1234, output_tokens: 56 }
})

// Add tool result
messageRenderer.addToolResult({
  tool_use_id: "call_123",
  content: [{ type: "text", text: "Found 5 results..." }],
  is_error: false,
  duration_ms: 340
})
```

**Formatting guidelines:**
- Use `BoxRenderable` with borders for message separation
- Color-code roles: User (#00FF00), Assistant (#00AAFF), System (#FFAA00)
- Indent tool calls and results for hierarchy
- Show token usage and costs in footer
- Collapse long reasoning blocks with toggle (spacebar)

### Interactive Conversation Loop

The `ConversationLoop` component orchestrates the full REPL experience.

**Core responsibilities:**
1. Render conversation history (scrollable)
2. Handle user input (multi-line)
3. Call Agent SDK `query()` on submit
4. Stream responses and update display
5. Manage focus states (input vs history scrolling)

**State management:**
```typescript
class ConversationLoop {
  private messages: Message[] = []
  private isProcessing: boolean = false
  private input: MultilineInput
  private history: MessageRenderer
  private statusBar: TextRenderable

  async handleSubmit(userInput: string) {
    if (this.isProcessing) return

    this.isProcessing = true
    this.statusBar.content = "🤔 Thinking..."

    // Add user message to history
    this.history.addMessage({ role: "user", content: userInput })

    // Call Agent SDK
    try {
      const response = await query(userInput, this.tools)
      this.history.addMessage(response)
    } catch (error) {
      this.history.addError(error)
    } finally {
      this.isProcessing = false
      this.statusBar.content = "Ready"
      this.input.clear()
      this.input.focus()
    }
  }
}
```

**Keyboard shortcuts:**
- `Ctrl+Enter` - Submit input
- `Up/Down` - Scroll history (when history focused)
- `Tab` - Insert tab (when input focused)
- `Escape` - Toggle focus between input and history
- `Ctrl+L` - Clear conversation
- `Ctrl+C` - Exit (if configured)

### OpenTUI Console Overlay

OpenTUI includes a built-in console overlay for debugging without disrupting your TUI. Perfect for logging tool calls, errors, and debug info while the conversation runs.

**Setup:**
```typescript
const renderer = await createCliRenderer({
  exitOnCtrlC: true,
  consoleOptions: {
    position: ConsolePosition.BOTTOM,
    sizePercent: 30,
    colorInfo: "#00FFFF",
    colorWarn: "#FFFF00",
    colorError: "#FF0000",
    startInDebugMode: false,
  },
})

// Log tool calls
console.log("Tool called:", toolName, args)

// Log errors
console.error("Tool failed:", error)

// Toggle console with backtick key
renderer.keyInput.on("keypress", (key) => {
  if (key.sequence === "`") {
    renderer.console.toggle()
  }
})
```

**Console shortcuts:**
- `` ` `` - Toggle console visibility
- `Arrow keys` - Scroll when focused
- `+/-` - Resize console height
- `Ctrl+P/Ctrl+O` - Change position (top/bottom/left/right)

## Advanced Patterns

### Streaming Response Rendering

Agent SDK supports streaming responses. Update the TUI progressively as tokens arrive:

```typescript
import { queryStream } from "@anthropic-ai/claude-agent-sdk"

async function handleStreamingQuery(userInput: string) {
  const stream = queryStream(userInput, tools)
  const messageBox = this.history.createPlaceholder()

  for await (const chunk of stream) {
    if (chunk.type === "content_block_delta") {
      messageBox.appendText(chunk.delta.text)
    } else if (chunk.type === "tool_use") {
      messageBox.addToolCall(chunk)
    }
    // Renderer auto-updates on change
  }
}
```

### Custom Syntax Highlighting

Integrate Tree-sitter for code block highlighting in messages:

```typescript
import { TreeSitterStyledText } from "@opentui/core"

const codeBlock = new TreeSitterStyledText(renderer, {
  id: "code-block",
  content: toolResult.code,
  language: "typescript",
  theme: "monokai",
  position: "relative",
})

messageRenderer.add(codeBlock)
```

See `references/opentui-patterns.md` for Tree-sitter setup details.

### Layout Strategies

**Option 1: Fixed Split (Input Bottom)**
```
┌─────────────────────────────┐
│  Conversation History       │
│  (Scrollable)               │
│                             │
├─────────────────────────────┤
│  Multi-line Input           │
│  (Fixed 10 lines)           │
└─────────────────────────────┘
```

**Option 2: Flexible Split**
```typescript
const container = new GroupRenderable(renderer, {
  flexDirection: "column",
  width: "100%",
  height: "100%",
})

const history = new BoxRenderable(renderer, {
  flexGrow: 3, // 75% of space
  overflow: "scroll",
})

const input = new MultilineInput(renderer, {
  flexGrow: 1, // 25% of space
  minHeight: 5,
})

container.add(history)
container.add(input)
```

**Option 3: Modal Input (Full-screen toggle)**
- Default: Show history only
- `Ctrl+N` - Open full-screen input modal
- `Ctrl+Enter` - Submit and return to history

## Resources

### references/
- `opentui-patterns.md` - Deep-dive into input handling, keyboard events, focus management, and Tree-sitter integration

### assets/
- `evna-tui-template/` - Complete boilerplate for Agent SDK + OpenTUI REPL
  - `tui.ts` - Main entry point
  - `components/MultilineInput.ts` - Multi-line input with tabs
  - `components/MessageRenderer.ts` - Agent SDK message formatter
  - `components/ConversationLoop.ts` - Full REPL orchestrator
  - `types.ts` - TypeScript types for messages, state

## Common Patterns

**Pattern: Agent SDK + OpenTUI Integration**
```typescript
// main.ts
import { createCliRenderer } from "@opentui/core"
import { query, tool } from "@anthropic-ai/claude-agent-sdk"
import { ConversationLoop } from "./components/ConversationLoop"

// Define tools
const tools = [
  tool("search", "Search knowledge base", { query: z.string() }, async (args) => {
    // Tool implementation
  })
]

// Create renderer
const renderer = await createCliRenderer({ exitOnCtrlC: true })

// Create conversation loop
const loop = new ConversationLoop(renderer, {
  tools,
  onSubmit: async (input) => await query(input, tools),
  formatMessage: (msg) => formatAgentMessage(msg),
})

// Start
renderer.start()
```

**Pattern: Error Handling**
```typescript
try {
  const response = await query(userInput, tools)
  messageRenderer.addMessage(response)
} catch (error) {
  if (error.message.includes("rate limit")) {
    messageRenderer.addError("Rate limited. Retry in 60s.", "warning")
  } else {
    messageRenderer.addError(error.message, "error")
    console.error("Query failed:", error)
  }
}
```

**Pattern: Token/Cost Tracking**
```typescript
let totalInputTokens = 0
let totalOutputTokens = 0
let totalCost = 0

function updateUsage(response: AgentResponse) {
  const usage = response.usage
  totalInputTokens += usage.input_tokens
  totalOutputTokens += usage.output_tokens

  // Sonnet 4.5 pricing (example)
  const inputCost = (usage.input_tokens / 1_000_000) * 3.00
  const outputCost = (usage.output_tokens / 1_000_000) * 15.00
  totalCost += inputCost + outputCost

  statusBar.content = `Tokens: ${totalInputTokens}↑ ${totalOutputTokens}↓ | Cost: $${totalCost.toFixed(4)}`
}
```

## Next Steps

1. **Copy boilerplate**: Copy `assets/evna-tui-template/` to your project
2. **Customize components**: Adjust colors, layouts, keyboard shortcuts
3. **Integrate tools**: Wire up your Agent SDK tools to the conversation loop
4. **Test iteratively**: Run `bun run tui.ts` and refine the UX
5. **Add features**: Streaming, syntax highlighting, conversation history persistence

For detailed implementation examples, see `references/opentui-patterns.md`.
